from datetime import date
from typing import Dict
import math

def generate_rainfall_forecast(lat: float, lon: float, forecast_date: date) -> Dict:
    """
    Deterministic placeholder forecast:
    - Uses a simple function of lat/lon and day to compute rainfall_mm and probability.
    Replace this function with your real forecasting model or external API integration.

    Returns:
        { "rainfall_mm": float, "probability": float }
    """
    # Simple deterministic pseudo-forecast:
    day_factor = forecast_date.toordinal() % 30  # 0-29
    lat_factor = abs(lat) % 10
    lon_factor = abs(lon) % 10

    # rainfall value (0-100 mm)
    rainfall_mm = max(0.0, 30.0 + (lat_factor - 5.0) * 2.0 + (lon_factor - 5.0) * 1.5 + (day_factor - 15) * 0.6)
    rainfall_mm = round(rainfall_mm, 2)

    # probability (0-1) from rainfall magnitude (simple mapping)
    probability = min(1.0, max(0.0, rainfall_mm / 100.0 + 0.1 * math.sin(day_factor)))
    probability = round(probability, 3)

    return {"rainfall_mm": rainfall_mm, "probability": probability}