from typing import Optional
from pydantic import BaseModel, Field
from datetime import date


class Location(BaseModel):
    lat: float = Field(..., description="Latitude in decimal degrees")
    lon: float = Field(..., description="Longitude in decimal degrees")


class ProductCreateRequest(BaseModel):
    name: str = Field(..., description="Human-readable product name")
    location: Location
    date: date = Field(..., description="Forecast date (YYYY-MM-DD)")


class Forecast(BaseModel):
    rainfall_mm: float = Field(..., description="Forecast rainfall in millimeters")
    probability: float = Field(..., ge=0.0, le=1.0, description="Probability of rainfall (0-1)")


class ProductResponse(BaseModel):
    id: str
    name: str
    location: Location
    date: date
    forecast: Forecast